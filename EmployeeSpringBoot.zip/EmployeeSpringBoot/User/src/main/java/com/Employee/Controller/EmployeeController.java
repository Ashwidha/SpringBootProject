package com.Employee.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.Entity.Employee;
import com.Employee.Repository.EmployeeRepository;
import com.Employee.Service.EmployeeService;
import com.Employee.exception.ControllerException;

@RequestMapping("employee")
@RestController
public class EmployeeController {
	
	 private EmployeeService employeeService;

	    @Autowired
	    public EmployeeController(EmployeeService employeeService) {
	        this.employeeService = employeeService;
	    }
	
	  @PostMapping("/add")
	    public ResponseEntity<?> saveEmployee(@RequestBody Employee employee) {
		  try{
			  Employee savedEmployee = employeeService.saveEmployee(employee);
		        return new ResponseEntity<Employee>(savedEmployee, HttpStatus.CREATED);
			}catch(Exception e)
			{
				ControllerException ce = new ControllerException("404", "Something went wrong!! Please check controller postmapping");
				return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
			}
	      
	    }


	    @GetMapping("/all")
	    public ResponseEntity<List<Employee>> getAllEmployee() {
	        return new ResponseEntity<List<Employee>>((List<Employee>) employeeService.getAllEmployee(), HttpStatus.OK);

	    }

  

  
	    @GetMapping("/{id}")
	    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Long id) {
	        return new ResponseEntity<Employee>(employeeService.getEmployeeById(id), HttpStatus.FOUND);
	    }


  
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Employee> getEmployeeAfterDeleting(@PathVariable("id") Long id) {
	        return new ResponseEntity<Employee>(employeeService.deleteEmployee(id), HttpStatus.OK);
	    }

 
	    @PutMapping("/update")
	    public ResponseEntity<?> updateEmployee(@RequestBody Employee employee) {
	    	try{
	    		 Employee updatedEmployee = employeeService.updateEmployee(employee);
	 	        return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
			}catch(Exception e)
			{
				ControllerException ce = new ControllerException("404", "Something went wrong!! Please check controller postmapping");
				return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
			}
	       
	    }
}