package com.Employee.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Employee.Entity.Employee;
@Service
public interface EmployeeService {
	
	
	    Employee saveEmployee(Employee employee);

	 
	    List<Employee> getAllEmployee();

	  
	    Employee getEmployeeById(Long id);

	  
	    Employee deleteEmployee(Long id);

	   
	    Employee updateEmployee(Employee employee);
	}


