package com.Employee.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Employee.Entity.Employee;
import com.Employee.Repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeRepository employeeRepository;
	
	@Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }
	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Employee savedemployee = employeeRepository.save(employee);
        return savedemployee;
	
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return (List<Employee>) employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(Long id) {
		// TODO Auto-generated method stub
		Employee employee = null;
	
	        employee = employeeRepository.findById(id).get();
	        return employee;
	}

	@Override
	public Employee deleteEmployee(Long id) {
		// TODO Auto-generated method stub
		Employee employee = null;
        Optional optional = employeeRepository.findById(id);
        if (optional.isPresent()) {
            employee = employeeRepository.findById(id).get();
            employeeRepository.deleteById(id);
        }
        return employee;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		 Employee updatedEmployee = null;
	        Optional optional = employeeRepository.findById(employee.getId());
	        if (optional.isPresent()) {
	           Employee getEmployee = employeeRepository.findById(employee.getId()).get();
	            getEmployee.setEmail(employee.getEmail());
	           
	            getEmployee.setFirstname(employee.getFirstname());
	            getEmployee.setLastname(employee.getLastname());
	           
	            updatedEmployee = saveEmployee(getEmployee);
	            System.out.println(updatedEmployee);
	        }
	        return updatedEmployee;
	}


}
